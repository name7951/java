package week10;

public class Sum {

	public static void main(String[] args) {

		int[] array1 = { 1, 2, 3 };
		int[][] array2 = { { 12, 4 }, { 8, 10, 9 } };
		int[][][] array3 = { { { 1, 12, 7 }, { 6, 4 } }, { { 5, 8 }, { 17, 3, 5 } }, { { 9, 10 }, { 5, 1 } } };

		System.out.println("sum of array1 : "); // 1차원 배열의 모든 값의 합 출력
		System.out.println("sum of array2 : "); // 2차원 배열의 모든 값의 합 출력
		System.out.println("sum of array3 : "); // 3차원 배열의 모든 값의 합 출력

	}

	public static int sumOfArray(int array1) {

		return array1;
	}

	public static int sumOfArray(int array2) {

		return array2;
	}

	public static int sumOfArray(int array3) {

		return array3;
	}

}
